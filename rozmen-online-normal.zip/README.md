# ROZMEN RESELLING - VERSION NORMAL (SIN PNG)

Esta versión usa las imágenes NORMALES con fondo, como pediste. Sin PNG transparentes.

- public/index.html -> Tu diseño original intacto + backend online
- Imágenes originales con fondo en public/

## Clave Admin: Roman1805!

## Para hacerlo ONLINE GLOBAL:

1. Supabase.com -> New Project -> SQL Editor pega:

create table productos (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  price text,
  image text not null,
  stock boolean default true,
  created_at timestamp default now()
);
alter table productos enable row level security;
create policy "public read" on productos for select using (true);
create policy "public insert" on productos for insert with check (true);
create policy "public delete" on productos for delete using (true);
create policy "public update" on productos for update using (true) with check (true);

2. Settings -> API -> copia URL y anon key

3. Abre la web y en consola (F12) escribe:
ROZMEN_CONFIG.setSupabaseKeys('TU_URL', 'TU_ANON_KEY')

O crea .env.local si usas Vercel:
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
NEXT_PUBLIC_ADMIN_PASSWORD=Roman1805!

4. Sube a Vercel y listo. Solo vos con Roman1805! podes editar, y todos ven los cambios.

WhatsApp: 5491131149177 con mensaje automatico.
